
--
-- Index pour les tables exportées
--

--
-- Index pour la table `cursus`
--
ALTER TABLE `cursus`
  ADD PRIMARY KEY (`id`),
  ADD KEY `numeroEtu` (`numeroEtu`);

--
-- Index pour la table `elementcursus`
--
ALTER TABLE `elementcursus`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idCursus` (`idCursus`);

--
-- Index pour la table `etudiant`
--
ALTER TABLE `etudiant`
  ADD PRIMARY KEY (`numero`);

--
-- Index pour la table `regle`
--
ALTER TABLE `regle`
  ADD PRIMARY KEY (`label`),
  ADD KEY `idReglement` (`idReglement`);

--
-- Index pour la table `reglement`
--
ALTER TABLE `reglement`
  ADD PRIMARY KEY (`id`);
