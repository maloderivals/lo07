
-- --------------------------------------------------------

--
-- Structure de la table `etudiant`
--

CREATE TABLE `etudiant` (
  `nom` varchar(25) NOT NULL,
  `prenom` varchar(20) NOT NULL,
  `numero` int(5) NOT NULL,
  `filliere` varchar(3) NOT NULL,
  `admission` varchar(2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
