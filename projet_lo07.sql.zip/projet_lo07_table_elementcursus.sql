
-- --------------------------------------------------------

--
-- Structure de la table `elementcursus`
--

CREATE TABLE `elementcursus` (
  `id` int(11) NOT NULL,
  `num_semestre` varchar(2) NOT NULL,
  `label_semestre` varchar(4) NOT NULL,
  `sigle` varchar(4) NOT NULL,
  `categorie` varchar(2) NOT NULL,
  `affectation` varchar(4) NOT NULL,
  `utt` varchar(1) NOT NULL,
  `profil` varchar(1) NOT NULL,
  `credit` int(2) NOT NULL,
  `resultat` varchar(3) NOT NULL,
  `idCursus` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
