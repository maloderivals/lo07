
-- --------------------------------------------------------

--
-- Structure de la table `cursus`
--

CREATE TABLE `cursus` (
  `id` int(11) NOT NULL,
  `label` varchar(20) NOT NULL,
  `numeroEtu` int(5) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
