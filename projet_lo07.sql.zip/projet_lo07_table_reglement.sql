
-- --------------------------------------------------------

--
-- Structure de la table `reglement`
--

CREATE TABLE `reglement` (
  `id` int(11) NOT NULL,
  `label` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
