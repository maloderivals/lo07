
-- --------------------------------------------------------

--
-- Structure de la table `regle`
--

CREATE TABLE `regle` (
  `label` varchar(3) NOT NULL,
  `agregat` varchar(5) NOT NULL,
  `cible` varchar(10) NOT NULL,
  `affectation` float NOT NULL,
  `seuil` int(11) NOT NULL,
  `idReglement` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
